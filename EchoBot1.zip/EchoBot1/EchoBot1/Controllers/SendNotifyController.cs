﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System;
using Microsoft.Bot.Schema.Teams;
using System.Diagnostics;
using Activity = Microsoft.Bot.Schema.Activity;
using Microsoft.Graph;
using Azure.Identity;
using System.Collections.Generic;

namespace EchoBot1.Controllers
{    
    [Route("api/sendMessage/{action}")]
    [EnableCors("MyTabPolicy")]
    [ApiController]
    public class SendNotifyController : ControllerBase
    {
        private readonly IConfiguration Configuration;        

        public SendNotifyController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        [HttpPost]        
        public async Task<ActionResult> SendMessageConvoId()
        {
            // The client credentials flow requires that you request the
            // /.default scope, and preconfigure your permissions on the
            // app registration in Azure. An administrator must grant consent
            // to those permissions beforehand.
            var scopes = new[] { "https://graph.microsoft.com/.default" };

            // Multi-tenant apps can use "common",
            // single-tenant apps must use the tenant ID from the Azure portal
            var tenantId = "5653d922-a6e1-4e14-8ab0-51bf044f001d";

            // Values from app registration
            var clientId = "af1dfe3e-3044-4535-9c64-65840ba30354";
            var clientSecret = "hTR8Q~f0QuYTU5peJA3i02xrh43VFN7~6SWf.ayb";

            // using Azure.Identity;
            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };

            // https://docs.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
            var clientSecretCredential = new ClientSecretCredential(
                tenantId, clientId, clientSecret, options);

            var graphClient = new GraphServiceClient(clientSecretCredential, scopes);
            //GraphServiceClient graphClient = new GraphServiceClient(clientSecretCredential, scopes);

            var userScopeTeamsAppInstallation = new UserScopeTeamsAppInstallation
            {
                AdditionalData = new Dictionary<string, object>()
                {
                    {"teamsApp@odata.bind", "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps/6bf3c871-80bc-42bf-b2bc-5295e74fe451"}
                }
                        };

            await graphClient.Users["d0086085-30e1-4230-8c5a-16b3f40ec069"].Teamwork.InstalledApps
                .Request()
                .AddAsync(userScopeTeamsAppInstallation);
            return new OkResult();

            //string requestBody = await new System.IO.StreamReader(HttpContext.Request.Body).ReadToEndAsync();
            //dynamic bodyData = JsonConvert.DeserializeObject(requestBody);

            //string conversationId = bodyData?.conversationId;
            //string serviceUrl = bodyData?.serviceUrl;

            //var uri = new Uri(serviceUrl);
            //ConnectorClient connector = new ConnectorClient(uri, Configuration["MicrosoftAppId"], Configuration["MicrosoftAppPassword"]);
            //MicrosoftAppCredentials.TrustServiceUrl(serviceUrl);

            //var activity = new Activity()
            //{
            //    Text = "did it work, with convo id ?",
            //    Type = ActivityTypes.Message,
            //    Conversation = new ConversationAccount(false, "personal", conversationId)
            //};

            //try
            //{
            //    var result = await connector.Conversations.SendToConversationAsync(conversationId, activity);

            //    return new OkResult();
            //}
            //catch (Exception ex)
            //{
            //    return new BadRequestObjectResult(ex.Message);
            //}
        }
        [HttpPost]
        public async Task<ActionResult> SendMessageUserId()
        {
            string requestBody = await new System.IO.StreamReader(HttpContext.Request.Body).ReadToEndAsync();
            dynamic bodyData = JsonConvert.DeserializeObject(requestBody);

            string userId = bodyData?.userId;
            string serviceUrl = bodyData?.serviceUrl;

            var uri = new Uri(serviceUrl);
            ConnectorClient connector = new ConnectorClient(uri, Configuration["MicrosoftAppId"], Configuration["MicrosoftAppPassword"]);
            MicrosoftAppCredentials.TrustServiceUrl(serviceUrl);

            var parameters = new ConversationParameters
            {
                Bot = new ChannelAccount($"28:{Configuration["MicrosoftAppId"]}"),
                Members = new[] { new ChannelAccount(userId) }, // need to store it some where in cosmos db for each user
                ChannelData = new TeamsChannelData
                {
                    Tenant = new TenantInfo(Configuration["MicrosoftAppTenantId"]),
                },
            };
            var response = await connector.Conversations.CreateConversationAsync(parameters);
            // Construct the message to post to conversation
            var newActivity = new Activity
            {
                Text = "did it work, with user id?",
                Type = ActivityTypes.Message,
                Conversation = new ConversationAccount
                {
                    Id = response.Id
                },
            };
            
            try
            {
                // Post the message to chat conversation with user
                var result = await connector.Conversations.SendToConversationAsync(response.Id, newActivity);
                return new OkResult();
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }

        }
    }
}
